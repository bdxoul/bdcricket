<div id="footer">
&copy; <?php echo date('Y');?>, <?php echo $_SITE['name'];?> &middot; Developed by <a href="http://mirazmac.info">Miraz Mac</a>
<br/>
Data Source: <a href="http://www.espncricinfo.com" rel="external nofollow">Espncricinfo</a>
</div>
</body>
</html>